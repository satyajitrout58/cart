import { cartData } from "../resource/mockData";
import {
  UPDATE_CART_DATA,
  OPEN_MODAL,
  CLOSE_MODAL,
  SET_OPEN_ITEM,
  UPDATE_CART
} from "./actionType";
export const getCartData = () => {
  return {
    type: UPDATE_CART_DATA,
    cartData
  };
};

export const openModal = () => {
  return {
    type: OPEN_MODAL
  };
};

export const closeModal = () => {
  return {
    type: CLOSE_MODAL
  };
};

export const setOpenItem = payload => {
  return {
    type: SET_OPEN_ITEM,
    payload
  };
};

export const updateCart = payload => {
  return {
    type: UPDATE_CART,
    payload
  };
};
