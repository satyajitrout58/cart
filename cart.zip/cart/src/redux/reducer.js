import {
  UPDATE_CART_DATA,
  OPEN_MODAL,
  CLOSE_MODAL,
  SET_OPEN_ITEM,
  UPDATE_CART
} from "./actionType";
const initialState = {
  cartItem: [],
  pramocode: "Ajio",
  modal: false,
  openItem: {}
};

const Reducer = (state = initialState, action) => {
  switch (action.type) {
    case UPDATE_CART_DATA:
      return {
        ...state,
        cartItem: action.cartData
      };
    case OPEN_MODAL:
      return {
        ...state,
        modal: true
      };
    case CLOSE_MODAL:
      return {
        ...state,
        modal: false
      };
    case SET_OPEN_ITEM:
      return {
        ...state,
        openItem: action.payload
      };
    case UPDATE_CART:
      const { cartItem } = state;
      const newcartData = cartItem.map((val, index) => {
        if (val.p_id === action.payload.p_id) {
          val.p_selected_color.name = cartItem.color;
          val.p_selected_size.name = cartItem.size;
          val.p_quantity = cartItem.size;
        }
        return val;
      });
      return {
        ...state,
        cartItem: newcartData
      };
    default:
      return {
        ...state
      };
  }
};

export default Reducer;
