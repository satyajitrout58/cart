export const UPDATE_CART_DATA = "UPDATE_CART_DATA";
export const OPEN_MODAL = "OPEN_MODAL";
export const CLOSE_MODAL = "CLOSE_MODAL";
export const SET_OPEN_ITEM = "SET_OPEN_ITEM";
export const UPDATE_CART = "UPDATE_CART";
