import React, { Fragment, useState } from "react";
import productImg from "../asset/product.jpg";
import { Table, Row, Col, Image, Modal, Button } from "react-bootstrap";
const EditContent = props => {
  const [state, updateState] = useState({
    color: "",
    size: "",
    qty: ""
  });
  const { item } = props;
  console.log(props);
  const color = () => {
    const { item } = props;
    const newopt = item.p_available_options.colors.map((val, key) => {
      return (
        <Fragment>
          <option value={val.hexcode}>{val.name}</option>
        </Fragment>
      );
    });
    return newopt;
  };

  const size = () => {
    const { item } = props;
    const newopt = item.p_available_options.sizes.map((val, key) => {
      return (
        <Fragment key={key}>
          <option value={val.code}>{val.name}</option>
        </Fragment>
      );
    });
    return newopt;
  };
  const handleChange = e => {
    const { name, value } = e.target;
    console.log(name);
    updateState(prevState => {
      return {
        ...prevState,
        [name]: value
      };
    });
  };

  const handleClose = () => {
    props.setUpdate(state);
    props.closeModal();
  };

  return (
    <Fragment>
      <Row>
        <Col>
          <Image
            src={productImg}
            alt={item.p_name}
            className="cartIng"
            thumbnail
          />
        </Col>
        <Col>
          <Table>
            <tbody>
              <tr>
                <td>{item.p_name}</td>
              </tr>
              <tr>
                <td>{`${item.c_currency} ${item.p_price}`}</td>
              </tr>
              <tr>
                <td>
                  Color
                  <select name="color" onChange={handleChange}>
                    {color()}
                  </select>
                </td>
              </tr>
              <tr>
                <td>
                  Size
                  <select name="size" onChange={handleChange}>
                    {size()}
                  </select>
                  <input
                    type="text"
                    name="qty"
                    value={item.p_quantity}
                    onChange={handleChange}
                  />
                </td>
              </tr>
            </tbody>
          </Table>
        </Col>
      </Row>
      <Modal.Footer>
        <Button variant="primary" onClick={handleClose}>
          Save Changes
        </Button>
      </Modal.Footer>
    </Fragment>
  );
};

export default EditContent;
