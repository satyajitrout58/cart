import React, { useState } from "react";
import { Button, Modal } from "react-bootstrap";

const EditModal = props => {
  const [show, setShow] = useState(false);

  const handleClose = () => props.closeModal();
  const { openModal } = props;
  console.log(openModal);
  return (
    <>
      <Modal show={openModal} onHide={handleClose}>
        <Modal.Body>{props.children}</Modal.Body>>
      </Modal>
    </>
  );
};

export default EditModal;
