import React, { Fragment } from "react";
import productImg from "../asset/product.jpg";
import { Table, Row, Col, Image } from "react-bootstrap";
const Product = props => {
  const productList = () => {
    const { cartItem } = props;
    const cartItemList = cartItem.map(val => {
      return (
        <Fragment>
          <tr>
            <td>
              <Row>
                <Col>
                  <Image
                    src={productImg}
                    alt={val.p_name}
                    className="cartIng"
                    thumbnail
                  />
                </Col>
                <Col>
                  <p>{val.p_name}</p>
                  <p className="lightText">Style: #{val.p_style}</p>
                  <p className="lightText">
                    Color: #{val.p_selected_color.name}
                  </p>
                  <button className="cartbtn" onClick={() => props.edit(val)}>
                    Edit |
                  </button>
                  <button className="cartbtn">X Remove |</button>
                  <button className="cartbtn">Save For Later</button>
                </Col>
              </Row>
            </td>
            <td>{val.p_selected_size.code}</td>
            <td>
              <input
                type="text"
                value={val.p_quantity}
                name="qty"
                className="cartInput"
              />
            </td>
            <td>{`${val.c_currency} ${val.p_price}`}</td>
          </tr>
        </Fragment>
      );
    });
    return cartItemList;
  };

  const { pramocode } = props;
  console.log(props);
  return (
    <Fragment>
      <div className="row">
        <Table>
          <thead>
            <tr>
              <th>Item</th>
              <th>Size</th>
              <th>Qty</th>
              <th>Price</th>
            </tr>
          </thead>
          <tbody>{productList()}</tbody>
        </Table>
        <Col>
          <p>Need help or have question</p>
          <p className="lightText">Call Customer Service at: 1800000000</p>
          <p className="lightText">test test btestjhs ashfdkad</p>
        </Col>
        <Col pull-right>
          <p></p>
          <Table>
            <thead>
              <tr>
                <th>Enter Pramocode Or Gift Card</th>
                <th>
                  <input type="text" name="pramocode" value={pramocode} />
                </th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>Sub Total</td>
                <td></td>
              </tr>
              <tr>
                <td>Pramotion Codd {pramocode} applied</td>
                <td></td>
              </tr>
              <tr>
                <td>Estimated Shipping</td>
                <td>Free</td>
              </tr>
              <tr>
                <td>
                  <p>Estimated total</p>
                  <p style={{ fontSize: "6pt" }}>
                    Tax will be applied at checkout
                  </p>
                </td>
                <td></td>
              </tr>
            </tbody>
          </Table>
        </Col>
      </div>
    </Fragment>
  );
};

export default Product;
