import React, { Component } from "react";
import Product from "./Product";
import { connect } from "react-redux";
import {
  getCartData,
  openModal,
  closeModal,
  setOpenItem,
  updateCart
} from "../redux/action";
import EditModal from "./EditModal";
import EditContent from "./EditContent";

class Home extends Component {
  constructor() {
    super();
    this.openEdit = this.openEdit.bind(this);
    this.closeModal = this.closeModal.bind(this);
  }
  componentDidMount() {
    this.props.getCartData();
  }
  openEdit(val) {
    this.props.openModal();
    this.props.setOpenItem(val);
  }
  closeModal() {
    this.props.closeModal();
    console.log("close");
  }
  setUpdate(payload) {
    this.props.updateCart(payload);
  }
  render() {
    const { cartItem, pramocode, modal, openItem } = this.props;
    return (
      <div className="container">
        <h2>Your Shopping Cart</h2>
        <p className="headingText">
          If the Cart is completely empty then we should again add back the
          product for you
        </p>
        <Product
          cartItem={cartItem}
          pramocode={pramocode}
          edit={this.openEdit}
        />
        <EditModal openModal={modal} closeModal={this.closeModal}>
          <EditContent
            item={openItem}
            closeModal={this.closeModal}
            setUpdate={this.setUpdate}
          />
        </EditModal>
      </div>
    );
  }
}

const mapStateToProps = state => {
  return state;
};

const mapDispatchToProps = dispatch => {
  return {
    getCartData: () => dispatch(getCartData()),
    openModal: () => dispatch(openModal()),
    closeModal: () => dispatch(closeModal()),
    setOpenItem: payload => dispatch(setOpenItem(payload)),
    updateCart: payload => dispatch(updateCart(payload))
  };
};

export default connect(mapStateToProps, mapDispatchToProps)(Home);
